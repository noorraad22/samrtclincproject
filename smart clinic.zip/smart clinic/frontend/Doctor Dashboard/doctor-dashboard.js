
const navLinks = document.querySelectorAll(".doctor-sidebar nav a");
const pageElements = document.querySelectorAll(".doctor-main [data-page]");

function showPage(pageName) {

    // إظهار القسم المطلوب وإخفاء البقية
    pageElements.forEach(function(element) {
        element.hidden = element.dataset.page !== pageName;
    });

    // تحديث الخيار النشط
    navLinks.forEach(function(link) {
        link.classList.toggle(
            "active",
            link.getAttribute("href") === "#" + pageName
        );
    });
    // التحقق من تسجيل دخول الطبيب
if (sessionStorage.getItem("doctorLoggedIn") !== "true") {
    window.location.replace("doctor-login.html");
}

// تسجيل الخروج
const logoutButton = document.getElementById("doctor-logout");

logoutButton.addEventListener("click", function(event) {

    event.preventDefault();

    sessionStorage.removeItem("doctorLoggedIn");
    sessionStorage.removeItem("doctorName");

    window.location.href = "doctor-login.html";

});

    // منع الانتقال للأسفل
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

// التنقل بين الأقسام
navLinks.forEach(function(link) {

    link.addEventListener("click", function(event) {
        event.preventDefault();

        const pageName = this.getAttribute("href").substring(1);

        showPage(pageName);
    });

});

// الصفحة الافتراضية
showPage("dashboard");


// البحث عن المرضى
const searchInput = document.getElementById("patient-search");
const appointmentsList = document.getElementById("appointments-list");

searchInput.addEventListener("input", function() {

    const searchValue = this.value.toLowerCase();
    const rows = appointmentsList.querySelectorAll("tr");

    rows.forEach(function(row) {

        const patientName = row.cells[0].textContent.toLowerCase();

        row.style.display = patientName.includes(searchValue)
            ? ""
            : "none";

    });

});


// تحديث الإحصائيات
function updateStatistics() {

    const rows = appointmentsList.querySelectorAll("tr");

    let completed = 0;
    let waiting = 0;

    rows.forEach(function(row) {

        const status = row.querySelector(".status");

        if (status.classList.contains("completed")) {
            completed++;
        } else {
            waiting++;
        }

    });

    document.getElementById("completed-count").textContent = completed;
    document.getElementById("waiting-count").textContent = waiting;
}


// أزرار المواعيد
appointmentsList.addEventListener("click", function(event) {

    if (event.target.classList.contains("start-btn")) {

        const row = event.target.closest("tr");
        const status = row.querySelector(".status");

        status.textContent = "مكتمل";
        status.className = "status completed";

        event.target.textContent = "تم الكشف";
        event.target.disabled = true;
        event.target.style.background = "#16a34a";

        updateStatistics();
    }

    if (event.target.classList.contains("details-btn")) {

        const row = event.target.closest("tr");
        const patientName = row.cells[0].textContent;

        alert("عرض الملف الطبي للمريض: " + patientName);
    }

});

updateStatistics();
