
const loginForm = document.getElementById("doctor-login-form");

const showPassword = document.getElementById("show-password");
const passwordInput = document.getElementById("doctor-password");

const message = document.getElementById("login-message");

// إظهار وإخفاء كلمة المرور
showPassword.addEventListener("change", function() {
    passwordInput.type = this.checked ? "text" : "password";
});

// بيانات الطبيب التجريبية
const demoEmail = "doctor@smartclinic.com";
const demoPassword = "123456";

// تسجيل الدخول
loginForm.addEventListener("submit", function(event) {

    event.preventDefault();

    const email = document.getElementById("doctor-email").value.trim();
    const password = passwordInput.value;

    if (email === demoEmail && password === demoPassword) {

        message.textContent = "تم تسجيل الدخول بنجاح!";
        message.style.color = "green";

        sessionStorage.setItem("doctorLoggedIn", "true");
        sessionStorage.setItem("doctorName", "د. أحمد محمد");

        setTimeout(function() {
            window.location.href = "doctor-dashboard.html";
        }, 700);

    } else {

        message.textContent = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        message.style.color = "red";

    }

});
