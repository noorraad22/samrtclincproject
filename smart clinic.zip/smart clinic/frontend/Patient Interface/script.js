
// ========================================
// 1. بيانات الأطباء
// ========================================

const doctors = [
    {
        id: 1,
        name: "د. سارة أحمد",
        specialty: "Cardiology",
        emoji: "👩‍⚕️",
        rating: "4.9",
        experience: "10 سنوات خبرة",
        price: 25000,
        about: "متخصصة في صحة القلب وأمراض الأوعية الدموية."
    },
    {
        id: 2,
        name: "د. عمر خالد",
        specialty: "Dermatology",
        emoji: "👨‍⚕️",
        rating: "4.8",
        experience: "8 سنوات خبرة",
        price: 20000,
        about: "متخصص في علاج أمراض الجلد والشعر."
    },
    {
        id: 3,
        name: "د. لينا حسن",
        specialty: "Pediatrics",
        emoji: "👩🏻‍⚕️",
        rating: "5.0",
        experience: "12 سنة خبرة",
        price: 20000,
        about: "متخصصة في صحة الأطفال والفحوصات الدورية."
    },
    {
        id: 4,
        name: "د. علي مصطفى",
        specialty: "Neurology",
        emoji: "🧑‍⚕️",
        rating: "4.7",
        experience: "9 سنوات خبرة",
        price: 30000,
        about: "متخصص في تشخيص ومتابعة أمراض الجهاز العصبي."
    },
    {
        id: 5,
        name: "د. مريم سعد",
        specialty: "Family Medicine",
        emoji: "👩‍⚕️",
        rating: "4.9",
        experience: "7 سنوات خبرة",
        price: 15000,
        about: "متخصصة في الرعاية الصحية الأولية والفحوصات."
    },
    {
        id: 6,
        name: "د. ياسين رعد",
        specialty: "Cardiology",
        emoji: "👨🏻‍⚕️",
        rating: "4.8",
        experience: "11 سنة خبرة",
        price: 25000,
        about: "متخصص في أمراض القلب والوقاية منها."
    }
];


// ========================================
// 2. المتغيرات الأساسية
// ========================================

let selectedTime = "10:30 صباحاً";

let bookings = [];

let queueIndex = 0;


// ========================================
// 3. دوال مساعدة
// ========================================

const $ = (selector) => document.querySelector(selector);

const $$ = (selector) => [...document.querySelectorAll(selector)];


// ترجمة الاختصاصات
function specialtyArabic(specialty) {

    const specialties = {
        "Cardiology": "أمراض القلب",
        "Dermatology": "الأمراض الجلدية",
        "Pediatrics": "طب الأطفال",
        "Neurology": "طب الأعصاب",
        "Family Medicine": "طب الأسرة"
    };

    return specialties[specialty] || specialty;

}


// الحصول على تاريخ الغد
function tomorrow() {

    const date = new Date();

    date.setDate(date.getDate() + 1);

    const year = date.getFullYear();

    const month = String(date.getMonth() + 1).padStart(2, "0");

    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;

}


// تنسيق الأسعار
function money(amount) {

    return amount.toLocaleString("en-US") + " دينار عراقي";

}


// إظهار رسالة تنبيه
function showToast(message) {

    const toast = $("#toast");

    toast.textContent = message;

    toast.classList.add("show");

    setTimeout(() => {

        toast.classList.remove("show");

    }, 2600);

}


// ========================================
// 4. التنقل بين الصفحات
// ========================================

function go(page) {

    // إظهار الصفحة المطلوبة
    $$(".page").forEach(section => {

        section.classList.toggle(
            "active",
            section.id === page
        );

    });


    // تحديث زر الصفحة النشطة
    $$(".nav-link").forEach(button => {

        button.classList.toggle(
            "active",
            button.dataset.page === page
        );

    });


    // إغلاق المساعد
    $("#chatbox").classList.remove("open");


    // الانتقال إلى أعلى الصفحة
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });


    // تحديث المواعيد
    if (page === "appointments") {

        renderAppointments();

    }

}


// أزرار القائمة الرئيسية
$$("[data-page]").forEach(button => {

    button.addEventListener("click", (event) => {

        event.preventDefault();

        go(button.dataset.page);

    });

});


// الأزرار التي تنقل إلى صفحات أخرى
$$("[data-go]").forEach(button => {

    button.addEventListener("click", () => {

        go(button.dataset.go);

    });

});


// ========================================
// 5. عرض الأطباء
// ========================================

function renderDoctors() {

    const searchValue = $("#doctorSearch").value.trim().toLowerCase();

    const specialtyValue = $("#specialtyFilter").value;


    // البحث والتصفية
    const filteredDoctors = doctors.filter(doctor => {

        const arabicSpecialty = specialtyArabic(doctor.specialty);

        const matchesSearch =
            doctor.name.toLowerCase().includes(searchValue) ||
            doctor.specialty.toLowerCase().includes(searchValue) ||
            arabicSpecialty.includes(searchValue);

        const matchesSpecialty =
            !specialtyValue ||
            doctor.specialty === specialtyValue;

        return matchesSearch && matchesSpecialty;

    });


    // إنشاء بطاقات الأطباء
    $("#doctorGrid").innerHTML = filteredDoctors.map(doctor => `

        <article class="doctor-card">

            <div class="doctor-top">

                <div class="doctor-photo">
                    ${doctor.emoji}
                </div>

                <div>
                    <h3>${doctor.name}</h3>

                    <div class="specialty-name">
                        ${specialtyArabic(doctor.specialty)}
                    </div>
                </div>

            </div>

            <div class="rating">

                ★ ${doctor.rating}

                <span class="experience">
                    · ${doctor.experience}
                </span>

            </div>

            <p class="doctor-description">
                ${doctor.about}
            </p>

            <div class="doctor-footer">

                <div class="price">

                    ${money(doctor.price)}

                    <small>سعر الكشف</small>

                </div>

                <button
                    class="btn primary"
                    data-bookdoc="${doctor.id}"
                >
                    احجز الآن
                </button>

            </div>

        </article>

    `).join("") || `

        <div class="empty">
            لم يتم العثور على أطباء.
        </div>

    `;


    // أزرار حجز الأطباء
    $$("[data-bookdoc]").forEach(button => {

        button.addEventListener("click", () => {

            $("#bookDoctor").value = button.dataset.bookdoc;

            go("booking");

        });

    });

}


// البحث عن طبيب
$("#doctorSearch").addEventListener("input", renderDoctors);


// التصفية حسب الاختصاص
$("#specialtyFilter").addEventListener("change", renderDoctors);


// ========================================
// 6. اختيار الاختصاص من الرئيسية
// ========================================

$$("[data-specialty]").forEach(button => {

    button.addEventListener("click", () => {

        $("#specialtyFilter").value = button.dataset.specialty;

        $("#doctorSearch").value = "";

        renderDoctors();

        go("doctors");

    });

});


// ========================================
// 7. إعداد نموذج الحجز
// ========================================


// إضافة الأطباء إلى القائمة
$("#bookDoctor").innerHTML += doctors.map(doctor => `

    <option value="${doctor.id}">
        ${doctor.name} - ${specialtyArabic(doctor.specialty)}
    </option>

`).join("");


// تحديد أقل تاريخ للحجز
$("#bookDate").min = tomorrow();

$("#bookDate").value = tomorrow();


// اختيار وقت الموعد
$$(".slot").forEach(button => {

    button.addEventListener("click", () => {

        $$(".slot").forEach(slot => {

            slot.classList.remove("selected");

        });

        button.classList.add("selected");

        selectedTime = button.dataset.time;

    });

});


// ========================================
// 8. تأكيد الحجز
// ========================================

$("#confirmBooking").addEventListener("click", () => {

    const doctorId = Number($("#bookDoctor").value);

    const doctor = doctors.find(d => d.id === doctorId);

    const date = $("#bookDate").value;

    const patientName = $("#patientName").value.trim();


    // التحقق من الحقول
    if (!doctor || !date || !patientName) {

        showToast("يرجى ملء جميع الحقول.");

        return;

    }


    // التحقق من التاريخ
    if (date < tomorrow()) {

        showToast("يرجى اختيار تاريخ صحيح في المستقبل.");

        return;

    }


    // إنشاء رقم الحجز
    const bookingId =
        "SC-" + Math.floor(1000 + Math.random() * 9000);


    // إنشاء بيانات الموعد
    const newBooking = {

        id: bookingId,

        doctorId: doctor.id,

        date: date,

        time: selectedTime,

        patient: patientName,

        status: "مؤكد"

    };


    // إضافة الموعد إلى القائمة
    bookings.unshift(newBooking);


    // تحديث معلومات الدور
    queueIndex = 0;

    updateQueue(newBooking);


    // تحديث صفحة المواعيد
    renderAppointments();


    // الانتقال إلى صفحة المواعيد
    go("appointments");


    // رسالة نجاح
    showToast("تم إنشاء الحجز بنجاح: " + bookingId);

});


// ========================================
// 9. عرض المواعيد
// ========================================

function renderAppointments() {

    const list = $("#appointmentList");


    // التحقق من وجود مواعيد
    if (bookings.length === 0) {

        list.innerHTML = `

            <div class="empty">

                لا توجد مواعيد حالياً.

                يمكنك حجز موعدك الأول الآن.

            </div>

        `;

        return;

    }


    // إنشاء بطاقات المواعيد
    list.innerHTML = bookings.map(booking => {

        const doctor = doctors.find(
            d => d.id === booking.doctorId
        );

        const date = new Date(booking.date + "T12:00:00");

        const day = date.getDate();

        const month = date.toLocaleString("ar-IQ", {
            month: "long"
        });


        return `

            <article class="appointment">

                <div class="date-box">

                    <strong>${day}</strong>

                    <small>${month}</small>

                </div>


                <div class="appointment-details">

                    <strong>${doctor.name}</strong>

                    <small>

                        ${specialtyArabic(doctor.specialty)}

                        · ${booking.time}

                        <br>

                        رقم الحجز: ${booking.id}

                    </small>

                </div>


                <span class="status">
                    ${booking.status}
                </span>


                <button
                    class="outline"
                    data-track="${booking.id}"
                >
                    متابعة الدور
                </button>

            </article>

        `;

    }).join("");


    // أزرار متابعة الدور
    $$("[data-track]").forEach(button => {

        button.addEventListener("click", () => {

            const booking = bookings.find(
                item => item.id === button.dataset.track
            );

            queueIndex = bookings.indexOf(booking);

            updateQueue(booking);

            go("queue");

        });

    });

}


// ========================================
// 10. متابعة الدور
// ========================================

function updateQueue(booking) {

    if (!booking) return;

    const doctor = doctors.find(
        d => d.id === booking.doctorId
    );

    const queueNumber = 8 + queueIndex;

    const people = 4 + queueIndex;

    const waitingTime = 25 + (queueIndex * 5);


    // رقم الدور
    $("#queueNumber").textContent =
        "A-" + String(queueNumber).padStart(2, "0");


    // اسم الطبيب واختصاصه
    $("#queueDoctor").textContent =
        doctor.name + " · " + specialtyArabic(doctor.specialty);


    // وقت الموعد
    $("#queueTime").textContent = booking.time;


    // عدد الأشخاص قبلك
    $("#peopleAhead").textContent =
        people + " مرضى";


    // وقت الانتظار
    $("#waitTime").textContent =
        "حوالي " + waitingTime + " دقيقة";

}


// ========================================
// 11. المساعد الذكي التجريبي
// ========================================


// فتح المساعد
$("#chatToggle").addEventListener("click", () => {

    $("#chatbox").classList.toggle("open");

});


// إغلاق المساعد
$("#chatClose").addEventListener("click", () => {

    $("#chatbox").classList.remove("open");

});


// ========================================
// 12. تشغيل التطبيق
// ========================================


// عرض الأطباء عند فتح الموقع
renderDoctors();


// عرض المواعيد
renderAppointments();

function loginDemo(event) {
    event.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const message = document.getElementById("login-message");

    if (email && password) {
        message.textContent = "تم تسجيل الدخول تجريبياً بنجاح!";
        message.style.color = "green";
    }
}
