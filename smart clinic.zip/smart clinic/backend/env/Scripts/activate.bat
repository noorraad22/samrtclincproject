@rem This file is UTF-8 encoded, so we need to update the current code page while executing it
@for /f "tokens=2 delims=:." %%a in ('"%SystemRoot%\System32\chcp.com"') do @(
    @set _OLD_CODEPAGE=%%a
)
@if defined _OLD_CODEPAGE (
    @"%SystemRoot%\System32\chcp.com" 65001 > nul
)

@set "VIRTUAL_ENV=G:\smart clinic\backend\env"

@if not defined PROMPT @set PROMPT=$P$G

@if defined _OLD_VIRTUAL_PROMPT @set PROMPT=%_OLD_VIRTUAL_PROMPT%
@if defined _OLD_VIRTUAL_PYTHONHOME @set PYTHONHOME=%_OLD_VIRTUAL_PYTHONHOME%

@if not defined VIRTUAL_ENV_DISABLE_PROMPT @set "_OLD_VIRTUAL_PROMPT=%PROMPT%"
@if not defined VIRTUAL_ENV_DISABLE_PROMPT @set "PROMPT=(env) %PROMPT%"

@if defined PYTHONHOME @set _OLD_VIRTUAL_PYTHONHOME=%PYTHONHOME%
@set PYTHONHOME=

@if defined _OLD_VIRTUAL_PATH @set PATH=%_OLD_VIRTUAL_PATH%
@if not defined _OLD_VIRTUAL_PATH @set _OLD_VIRTUAL_PATH=%PATH%

@set "PATH=%VIRTUAL_ENV%\Scripts;%PATH%"
@set "VIRTUAL_ENV_PROMPT=env"

:END
@if defined _OLD_CODEPAGE (
    @"%SystemRoot%\System32\chcp.com" %_OLD_CODEPAGE% > nul
    @set _OLD_CODEPAGE=
)
